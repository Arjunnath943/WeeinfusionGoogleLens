//
//  ViewController.swift
//  WeeinfusionGoogleLens
//
//  Created by Arjun Nath on 18/02/22.
//  Copyright © 2022 Arjun Nath. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var displayImageView: UIImageView!
    @IBOutlet weak var searchImageButton: UIButton!
    let imagePicker = UIImagePickerController()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        imagePicker.delegate = self
        imagePicker.allowsEditing = false
        searchImageButton.isHidden = true
    }
    
    @IBAction func takePhotoAction(_ sender: Any) {
        if !UIImagePickerController.isSourceTypeAvailable(.camera) {
            let alertController = UIAlertController(title: nil, message: "Device has no camera.", preferredStyle: .alert)
            
            let okAction = UIAlertAction(title: "Alright", style: .default, handler: { (alert: UIAlertAction!) in
            })
            
            alertController.addAction(okAction)
            present(alertController, animated: true, completion: nil)
        } else {
            imagePicker.sourceType = .camera
            present(imagePicker, animated: true, completion: .none)
        }
    }
    
    @IBAction func selectPhotoAction(_ sender: Any) {
        imagePicker.sourceType = .photoLibrary
        present(imagePicker, animated: true, completion: .none)
    }
}
extension ViewController: UIImagePickerControllerDelegate, UINavigationControllerDelegate {
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        if let pickedImage = info[UIImagePickerController.InfoKey.originalImage] as? UIImage {
            displayImageView.contentMode = .scaleAspectFill
            displayImageView.image = pickedImage
            if displayImageView.image != .none {
                searchImageButton.isHidden = false
            }
        }
        dismiss(animated: true, completion: nil)
    }
    
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        dismiss(animated: true, completion: nil)
    }
}


